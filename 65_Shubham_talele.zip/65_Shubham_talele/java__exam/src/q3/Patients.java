package q3;
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
import java.util.Collection;

public class Patients {
 int patient_id;
 String name;
 String diagnosis;
 int num_of_days;
 int num_of_day_admitted;
 Collection<? extends Patients> morePatients;
public Patients() {
	super();
}
public Patients(int patient_id, String name, String diagnosis, int num_of_days, int num_of_day_admitted) {
	super();
	this.patient_id = patient_id;
	this.name = name;
	this.diagnosis = diagnosis;
	this.num_of_days = num_of_days;
	this.num_of_day_admitted = num_of_day_admitted;
}
@Override
public String toString() {
	return "Patients [patient_id=" + patient_id + ", name=" + name + ", diagnosis=" + diagnosis + ", num_of_days="
			+ num_of_days + ", num_of_day_admitted=" + num_of_day_admitted + "]";
}
 
}
class Patients_Manager{
	Scanner sc = new Scanner(System.in);
	Patients p = new Patients();
	List<Patients>pat = new ArrayList<>();
	
	
	public void Add_Patient() {
		System.out.println("enter the patient id :");
		int patient_id = sc.nextInt();
		System.out.println("enter the patient name :");
		String name = sc.next();
		System.out.println("enter the patient diagnosis :");
		String diagnosis = sc.next();
		System.out.println("enter the patient num_of_days :");
		int num_of_days = sc.nextInt();
		System.out.println("enter the patient num_of_day_admitted :");
		int num_of_day_admitted = sc.nextInt();
		pat.add(new Patients(patient_id , name , diagnosis , num_of_days , num_of_day_admitted));
		System.out.println("Patient data added succesfully ");
	}
	public void Remove_Patient() {
		System.out.println("enter the patient id :");
		int id = sc.nextInt();
		for(Patients p:pat) {
			if (id==p.patient_id) {
				pat.remove(p.patient_id);
			}
			else {
				System.out.println("enter the patient id not found..");
			}
		}
	}
	public void Find_Pati_Spec_Diagnos() {
		System.out.println("enter the diagnosis of patient :");
		String diagnosis = sc.next();
		for(Patients p:pat) {
			if(diagnosis.equalsIgnoreCase(diagnosis)) {
				System.out.println(p.diagnosis);
			}
		}
	}
	public void Find_Pati_More_admitt() {
//		System.out.println("enter the of patient id :");
//		int id = sc.nextInt();
		for(Patients p:pat) {
			//String morePatients;
			if(p.num_of_days > p.num_of_day_admitted) {
				pat.addAll(p.morePatients);
				System.out.println("patients name more admitted >> "+p.morePatients);
			}
		}
	}
}
class Patient_Management{
	public static void main(String[] args){
		int choice = 0;
		Patients_Manager pm = new Patients_Manager();
		
		do{
			Scanner sc = new Scanner(System.in);
			System.out.println("Patient management system");
			System.out.println("1. Add patient");
			System.out.println("2. Remove_Patient");
			System.out.println("3.Find_Pati_Spec_Diagnos");
			System.out.println("4. Find_Pati_More_admitt");
			switch(choice){
			
			case 1:{
				pm.Add_Patient();
				break;
			}
			case 2:{
				pm.Remove_Patient();
				break;
			}
			case 3:{
				pm.Find_Pati_Spec_Diagnos();
				break;
			}
			case 4:{
				pm.Find_Pati_More_admitt();
				break;
			}
			case 5:{
				System.out.println("exit succesfully ....");
				System.exit(0);
			}
			default:{
				System.out.println("enter the correct option :");
				break;
			}

			}
		}
		while(choice!=5 );
		
		
	}
}
