package q1;
import java.util.Scanner;


class NegativeException extends Exception(public NegativeException(String message) {
	super(message);
}

class Student{
	int Student_id;
	String name;
	double grades;
	
	public Student(){
		
	}
	public Student(int Student_id, String name, double grades) {
		this.Student_id = Student_id;
		this.name = name;
		this.grades = grades;
	}
	public void UpgradeGrade(double grade) throws NegativeException {
			if (grades < 0) {
				throw new NegativeException("grades must be positive");
			}
			else {
				System.out.println("student is grades are positive :"+this.grades);
			}
	}
	public void Display() {
		System.out.println("name is : "+Student_id);
		System.out.println("name is : "+name);
		System.out.println("name is : "+grades);
		
	}
}
class Student_use{
	public void main(String [] args) {
		Scanner scan = new Scanner(System.in);
		Student sc = new Student();
		System.out.println("enter the Student id  ");
		int student_id = scan.nextInt();
		System.out.println("enter the Student name  ");
		String name = scan.next();
		System.out.println("enter the grades :");
		double grades = scan.nextDouble();
		sc.Display();
		scan.close();
	}
}
