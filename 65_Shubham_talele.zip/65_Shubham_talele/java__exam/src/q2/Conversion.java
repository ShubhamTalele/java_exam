package q2;

public class Conversion {
 public static void main(Strings [] args) {
	 System.out.println("hello");
 }
}
